﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aim_Tracker
{
    internal class Counter
    {
        public int Cnt { get; set; }
    }
}

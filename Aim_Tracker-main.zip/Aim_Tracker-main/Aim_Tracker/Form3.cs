﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aim_Tracker
{
    public partial class Form3 : Form
    {
        DataTable dt = new DataTable();
        
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "ZgEIv9Z4dRvbzPwHMP6mRhxUKnI9zw2KWbkGFx5n",
            BasePath = "https://aimtracker-3f2f9-default-rtdb.firebaseio.com/"
        };

        IFirebaseClient client;

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            dt.Columns.Add("total");
            dt.Columns.Add("총점");
            dt.Columns.Add("평균 반응속도");

            dataGridView1.DataSource = dt;
            export();
        }

        private async void export()
        {
            dt.Rows.Clear();

            int i = 0;
            FirebaseResponse res = await client.GetAsync("AimTracker_Totalcounter/cnt");
            Counter c = res.ResultAs<Counter>();
            int cnt = c.Cnt;

            while (i != cnt)
            {
                i++;
                FirebaseResponse resp
                  = await client.GetAsync("AimTracker_Record/Record/" + i);
                Record r = resp.ResultAs<Record>();

                // 체크
                if (r != null)
                {
                    DataRow row = dt.NewRow();
                    row["total"] = r.Totalcnt;
                    row["총점"] = r.Gs + "점";
                    row["평균 반응속도"] = r.Totalrec + "초";

                    dt.Rows.Add(row);
                }
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show("저장된 데이터가 모두 삭제됩니다. 계속하시겠습니까?", "Warning!", MessageBoxButtons.YesNo,MessageBoxIcon.Warning);

            if (answer == DialogResult.No)
                return;

            var obj = new Counter
            {
                Cnt = 0
            };

            SetResponse res
              = await client.SetAsync("AimTracker_Totalcounter/cnt", obj);

            FirebaseResponse resp
              = await client.DeleteAsync("AimTracker_Record");

            dt.Rows.Clear();
            export();
            MessageBox.Show("모든 기록이 삭제되었습니다!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aim_Tracker
{
    internal class Record
    {
        public string Totalcnt { get; set; }
        public int Gs { get; set; }
        public double Totalrec { get; set; }
    }
}
